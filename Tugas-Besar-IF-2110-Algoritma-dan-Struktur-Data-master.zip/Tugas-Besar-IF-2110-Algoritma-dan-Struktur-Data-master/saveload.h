#include "player.h"
#include <stdio.h>
#include <string.h>

int M, N;
Player P1, P2;

void Save(int M, int N, Player P1, Player P2);

void Load(int *M, int *N, Player *P1, Player *P2);